# phonetizer-google

```
pip install phonetizer_google
```

# Usage
```
from Phonetizer import *

p=Phonetizer("hello world")
p.get_phoname()
```
